"""Part 1 runner: runs the assigned algorithm/instance pairs, fills the Task 1.6 table, prints tables.

    python run_all.py                    # required tasks + the full A-H comparison table
    python run_all.py --required-only    # only the tasks the assignment asks to be SOLVED
    python run_all.py --data PATH        # use another assignment_data.py (default: the one next to this file)
    python run_all.py --only bsgs,rho --instances C,C2
    python run_all.py --timeout 900 --budget-ops 1e8 --use-instance-params

THIS REQUIRES assignment_data.py (any of the layouts documented in data_loader.py).
Every recovered x is independently verified with pow(g, x, p) == h. Exit status: 0 if every REQUIRED task
passed, 1 otherwise. 'infeasible' / 'n/a' cells are results, not errors: the reason is printed.
"""
import argparse
import csv
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import bruteforce, bsgs, pollard_rho, pohlig_hellman, index_calculus, linear_sieve
import data_loader
import params
from common import SolverFailure, available_ram_bytes

RESULTS = os.path.join(HERE, "experiments", "results")
ALGS = ["bruteforce", "bsgs", "rho", "pohlig_hellman", "index_calculus", "linear_sieve"]
NAMES = {"bruteforce": "Brute force", "bsgs": "BSGS", "rho": "Pollard rho",
         "pohlig_hellman": "Pohlig-Hellman", "index_calculus": "Index calculus", "linear_sieve": "Linear sieve"}
# The tasks the assignment asks to be SOLVED (Part 1 table). (D brute force = extrapolation only.)
REQUIRED = [("bruteforce", "A"), ("bruteforce", "B"), ("bruteforce", "D"),
            ("bsgs", "A"), ("bsgs", "B"), ("bsgs", "C"),
            ("rho", "C"), ("rho", "C2"),
            ("pohlig_hellman", "D"), ("pohlig_hellman", "E"),
            ("index_calculus", "F"), ("index_calculus", "G"),
            ("linear_sieve", "G")]


# ------------------------------------------------------------------------------------ helpers
def fmt_years(sec):
    """Human-readable duration: seconds, minutes, hours, days or years."""
    years = sec / (365.25 * 24 * 3600)
    if years >= 1:
        return f"{years:.3g} years"
    for unit, size in (("days", 86400), ("hours", 3600), ("minutes", 60)):
        if sec >= size:
            return f"{sec / size:.3g} {unit}"
    return f"{sec:.3g} s"


def result(label, alg, status, required, **kw):
    r = {"instance": label, "algorithm": NAMES[alg], "alg": alg, "status": status, "required": required,
         "x": "-", "time_sec": None, "group_ops": "-", "memory_items": "-", "params": "", "reason": ""}
    r.update(kw)
    return r


def table_str(headers, rows, max_widths=None):
    data = [[str(c) for c in row] for row in rows]
    if max_widths:
        data = [[(c if len(c) <= w else c[:w - 3] + "...") if w else c for c, w in zip(row, max_widths)]
                for row in data]
    widths = [max(len(h), *(len(r[i]) for r in data)) if data else len(h) for i, h in enumerate(headers)]
    line = "+-" + "-+-".join("-" * w for w in widths) + "-+"
    out = [line, "| " + " | ".join(h.ljust(w) for h, w in zip(headers, widths)) + " |", line]
    out += ["| " + " | ".join(c.ljust(w) for c, w in zip(r, widths)) + " |" for r in data]
    return "\n".join(out + [line])


# ------------------------------------------------------------------------------------ planning
# Python-level cost per counted group operation, relative to one bare modular multiplication
# (dict work in BSGS, the walk function in rho). Rounded from measurements; used ONLY for estimates.
SPEED_FACTOR = {"bruteforce": 1.0, "bsgs": 2.5, "rho": 4.5, "pohlig_hellman": 2.5}
SECONDS_PER_YEAR = 365.25 * 24 * 3600
_RATE = {}


def mul_rate(inst):
    """Seconds per modular multiplication at this instance's number size (measured once, cached)."""
    if inst["p"] not in _RATE:
        _RATE[inst["p"]] = bruteforce.calibrate(inst["g"], inst["p"], 100_000)
    return _RATE[inst["p"]]


def estimate(alg, inst):
    """(estimated group operations, table entries) for one run of a generic algorithm."""
    n = inst["order"]
    root = math.isqrt(n) + 1
    if alg == "bruteforce":
        return n / 2, 0
    if alg == "bsgs":
        return 2 * root, root
    if alg == "rho":
        return 3 * 1.25 * root, 0                         # Floyd: 3 multiplications per iteration
    big = max(inst["factors"])
    r = math.isqrt(big) + 1
    return 2 * r * sum(inst["factors"].values()), r      # Pohlig-Hellman with inner BSGS


def plan(alg, label, inst, args):
    """Decide what to do with an OPTIONAL cell (and with every brute-force cell).
    Returns None (run it) or (status, reason) where status is
      N/A          - the algorithm does not apply to this instance
      INFEASIBLE   - estimated time above --infeasible-years, or more memory than the machine has
      NOT RUN      - feasible, but above the per-cell time / memory budget (raise --cell-seconds to measure it)
      EXTRAPOLATED - brute force on D: only extrapolated, as the assignment asks."""
    p = inst["p"]
    if not inst["p_is_prime"] or not inst["h_in_subgroup"] or inst["order"] <= 1:
        return "N/A", "; ".join(inst["notes"]) or "degenerate instance"
    if alg in ("index_calculus", "linear_sieve"):
        if not inst["safe_prime"]:
            return "N/A", "needs a safe prime p = 2q + 1"
        if not inst["generator"]:
            return "N/A", "g is not a generator of the whole group (order < p-1)"
        if p.bit_length() > args.max_ic_bits:
            return "NOT RUN", f"p has {p.bit_length()} bits (above --max-ic-bits {args.max_ic_bits})"
        return None
    if alg == "pohlig_hellman" and not inst["factors"]:
        return "N/A", "the group order could not be factored"

    ops, entries = estimate(alg, inst)
    rate = mul_rate(inst)
    seconds = ops * rate * SPEED_FACTOR[alg]
    memory = entries * params.BSGS_BYTES_PER_ENTRY
    ram = available_ram_bytes()
    if alg == "bruteforce":
        what = (f"n/2 = 2^{math.log2(ops):.0f} multiplications at {rate:.2e} s/op (measured on "
                f"{p.bit_length()}-bit numbers): about {fmt_years(seconds)} on average, "
                f"{fmt_years(2 * seconds)} worst case")
    else:
        what = f"about 2^{math.log2(ops):.0f} group operations, estimated {fmt_years(seconds)}"
        if entries:
            what += f", table of 2^{math.log2(entries):.0f} entries (~{memory / 2**30:.3g} GB)"
        if alg == "pohlig_hellman":
            what += f"; largest prime factor of the order has {max(inst['factors']).bit_length()} bits"
    too_slow = seconds > args.infeasible_years * SECONDS_PER_YEAR
    too_big = memory > 0.9 * ram
    if alg == "bruteforce" and label == "D" and (too_slow or too_big or seconds > args.cell_seconds):
        return "EXTRAPOLATED", what
    if too_slow or too_big:
        years = f"{args.infeasible_years:g} year" + ("" if args.infeasible_years == 1 else "s")
        limit = (f"more than {years}" if too_slow
                 else f"more memory than this machine has ({ram / 2**30:.0f} GB)")
        return "INFEASIBLE", f"{what} ({limit})"
    if seconds > args.cell_seconds or memory > args.ram_fraction * ram:
        limit = (f"above the {args.cell_seconds:g} s per-cell budget" if seconds > args.cell_seconds
                 else f"above {args.ram_fraction:.0%} of RAM")
        return "NOT RUN", f"{what} ({limit}; raise --cell-seconds / --ram-fraction to measure it)"
    return None


def required_precheck(alg, inst, args):
    """Required tasks always run, unless mathematically impossible (reported as N/A)."""
    if not inst["p_is_prime"] or not inst["h_in_subgroup"] or inst["order"] <= 1:
        return "N/A", "; ".join(inst["notes"]) or "degenerate instance"
    if alg in ("index_calculus", "linear_sieve"):
        if not inst["safe_prime"]:
            return "N/A", "needs a safe prime p = 2q + 1"
        if not inst["generator"]:
            return "N/A", "g is not a generator of the whole group"
    if alg == "bsgs":
        need = (math.isqrt(inst["order"]) + 1) * params.BSGS_BYTES_PER_ENTRY
        if need > 0.7 * available_ram_bytes():
            return "FAIL", f"BSGS table would need ~{need / 2**30:.1f} GB of RAM"
    if alg == "pohlig_hellman" and not inst["factors"]:
        return "FAIL", "the group order could not be factored"
    return None


# ------------------------------------------------------------------------------------ execution
def run_solver(alg, label, inst, args):
    g, h, p, n = inst["g"], inst["h"], inst["p"], inst["order"]
    seed = args.seed + sum((i + 1) * ord(c) for i, c in enumerate(label + alg))
    note = ""
    if alg == "bruteforce":
        x, st = bruteforce.solve(g, h, p, order=n)
    elif alg == "bsgs":
        x, st = bsgs.solve(g, h, p, order=n)
        note = f"m = {st['memory_items']:,}"
    elif alg == "rho":
        x, st = pollard_rho.solve(g, h, p, order=n, seed=seed, max_seconds=args.timeout)
        note = f"seed {seed}; iterations {st['iterations']:,} (1.25*sqrt(n) = {1.25 * math.sqrt(n):,.0f}); restarts {st['restarts']}"
    elif alg == "pohlig_hellman":
        x, st = pohlig_hellman.solve(g, h, p, order=n, factors=inst["factors"])
        k = len(st["factors"])
        note = (f"{k} prime factor{'' if k == 1 else 's'}; largest subgroup {st['largest_subgroup'].bit_length()} bits "
                f"(p has {p.bit_length()}); inner ops {st['inner_group_ops']:,}")
    elif alg == "index_calculus":
        B, src = params.ic_params(label, inst, args.use_instance_params)
        x, st = index_calculus.solve(g, h, p, order=n, B=B, seed=seed, max_seconds=args.timeout)
        note = (f"B={B} ({src}); factor base {st['factor_base_size']}; relations {st['relations']}; "
                f"rank {st['rank']}/{st['factor_base_size']}")
    else:
        (B, M), src = params.ls_params(label, inst, args.use_instance_params)
        x, st = linear_sieve.solve(g, h, p, order=n, B=B, M=M, seed=seed, max_seconds=args.timeout)
        note = (f"B={B}" + (f"->{st['B_final']}" if st["B_final"] != B else "") + f", M={M}"
                + (f"->{st['M_final']}" if st["M_final"] != M else "") + f" ({src}); unknowns "
                f"{st['factor_base_size']}; relations {st['relations']}; rank {st['rank']}/{st['factor_base_size']} "
                f"(full column rank: {'yes' if st['full_column_rank'] else 'NO'}; all prime logs determined: "
                f"{'yes' if st['factor_base_logs_determined'] else 'NO'})")
    if pow(g, x, p) != h:
        raise AssertionError("independent verification pow(g, x, p) == h failed")
    return x, st, note


def execute(alg, label, inst, args, required):
    if required and alg != "bruteforce":
        pre = required_precheck(alg, inst, args)
    else:                                   # brute force is ALWAYS gated: too big -> extrapolate, never run
        pre = plan(alg, label, inst, args)
    if pre:
        status, reason = pre
        return result(label, alg, status, required, reason=reason, params="-")
    t0 = time.perf_counter()
    try:
        x, st, note = run_solver(alg, label, inst, args)
        return result(label, alg, "PASS", required, x=x, time_sec=st["time_sec"], group_ops=st["group_ops"],
                      memory_items=st["memory_items"], params=note, stats=st)
    except SolverFailure as exc:
        timed_out = "time budget" in str(exc)
        status = "TIMEOUT" if timed_out and not required else "FAIL"
        return result(label, alg, status, required, time_sec=time.perf_counter() - t0, reason=str(exc))
    except MemoryError:
        return result(label, alg, "FAIL", required, time_sec=time.perf_counter() - t0, reason="out of memory")
    except Exception as exc:
        return result(label, alg, "FAIL", required, time_sec=time.perf_counter() - t0,
                      reason=f"{type(exc).__name__}: {exc}")


# ------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", default=None, help="path to an assignment_data.py")
    ap.add_argument("--only", default=",".join(ALGS), help="comma-separated: " + ", ".join(ALGS))
    ap.add_argument("--instances", default=None, help="comma-separated labels, e.g. A,C2,G")
    ap.add_argument("--required-only", action="store_true", help="skip the extra cells of the Task 1.6 table")
    ap.add_argument("--cell-seconds", type=float, default=120,
                    help="run an OPTIONAL cell only if its estimated time is below this (default 120 s)")
    ap.add_argument("--ram-fraction", type=float, default=0.3,
                    help="run an OPTIONAL cell only if its table fits in this fraction of RAM (default 0.3)")
    ap.add_argument("--infeasible-years", type=float, default=1.0,
                    help="cells estimated above this many years are reported as INFEASIBLE (default 1)")
    ap.add_argument("--max-ic-bits", type=int, default=72, help="largest p (bits) for optional IC / LS cells")
    ap.add_argument("--timeout", type=float, default=600, help="seconds allowed per rho / IC / LS run")
    ap.add_argument("--use-instance-params", action="store_true", help="use B_ic/B_ls/M_ls from assignment_data.py")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out", default=RESULTS, help="folder for results.csv / summary.* / details.json")
    args = ap.parse_args()
    try:
        instances, path = data_loader.load_instances(args.data)
    except data_loader.DataFormatError as exc:
        print("ERROR:", exc)
        return 2
    algs = [a for a in args.only.split(",") if a in ALGS]
    wanted = set(args.instances.split(",")) if args.instances else set(instances)
    labels = [lab for lab in instances if lab in wanted]

    print("Discrete Logarithm Assignment - Part 1")
    print(f"Python {sys.version.split()[0]} | data file: {path}")
    print("Instances: " + ", ".join(f"{lab} ({instances[lab]['p'].bit_length()} bits)" for lab in labels))
    for lab in labels:
        for note in instances[lab]["notes"]:
            print(f"  note [{lab}]: {note}")
    print(f"Parameters: index calculus F: B={params.IC_B['F']}, G: B={params.IC_B['G']}; linear sieve "
          f"B={params.LS_B}, M={params.LS_M} (assignment values; --use-instance-params to override)")
    print(f"Optional cells: run if estimated <= {args.cell_seconds:g} s and <= {args.ram_fraction:.0%} of RAM; "
          f"INFEASIBLE if > {args.infeasible_years:g} year(s) or more memory than this machine has\n")

    tasks = [(a, lab, True) for a, lab in REQUIRED if a in algs and lab in labels]
    missing = [(a, lab) for a, lab in REQUIRED if a in algs and lab not in instances]
    if missing:
        print("NOTE: required instance(s) not present in the data file: " + ", ".join(sorted({lab for _, lab in missing})))
    if not args.required_only:
        done = {(a, lab) for a, lab, _ in tasks}
        tasks += [(a, lab, False) for lab in labels for a in algs if (a, lab) not in done]
    rows = []
    for i, (alg, label, req) in enumerate(tasks, 1):
        print(f"[{i:>2}/{len(tasks)}] {label:<3} {NAMES[alg]:<15}{'(required)' if req else '(table)  '} ...", end=" ", flush=True)
        r = execute(alg, label, instances[label], args, req)
        rows.append(r)
        extra = f"{r['time_sec']:.4f} s" if r["status"] == "PASS" else r["reason"][:90]
        print(f"{r['status']}  {extra}", flush=True)

    # ------------------------------------------------ Table 1: every run
    order_key = {lab: i for i, lab in enumerate(instances)}
    rows.sort(key=lambda r: (order_key[r["instance"]], ALGS.index(r["alg"])))
    t1 = [[r["instance"], r["algorithm"], r["status"], r["x"],
           "-" if r["time_sec"] is None else f"{r['time_sec']:.4f}", r["group_ops"], r["memory_items"],
           r["params"] if r["status"] == "PASS" else r["reason"]] for r in rows]
    print("\nTABLE 1 - all runs (x is verified with pow(g, x, p) == h; 'infeasible' = not run, reason given)")
    print(table_str(["Inst", "Algorithm", "Status", "Recovered x", "Time (s)", "Group ops", "Memory", "Parameters / reason"],
                    t1, [0, 0, 0, 0, 0, 0, 0, 78]))

    # ------------------------------------------------ Table 2: Task 1.6 matrix
    notes, note_ids, mat = [], {}, []              # one numbered note per distinct (algorithm, reason)
    for alg in algs:
        line = [NAMES[alg]]
        for lab in labels:
            r = next((x for x in rows if x["alg"] == alg and x["instance"] == lab), None)
            if r is None:
                line.append("-")                          # not requested in this run
            elif r["status"] == "PASS":
                line.append(f"{r['time_sec']:.4g} s")
            else:
                key = (alg, r["reason"] or r["status"])
                if key not in note_ids:
                    note_ids[key] = len(notes) + 1
                    notes.append([NAMES[alg], [], key[1]])
                notes[note_ids[key] - 1][1].append(lab)
                line.append(f"{r['status'].lower()} [{note_ids[key]}]")
        mat.append(line)
    notes = [f"{a} on {', '.join(ls)}: {why}" for a, ls, why in notes]
    print("\nTABLE 2 - Task 1.6 summary (measured runtime, or the reason in the numbered note)")
    print(table_str(["Algorithm"] + labels, mat))
    for i, n in enumerate(notes, 1):
        print(f" [{i}] {n}")

    # ------------------------------------------------ files + summary
    out_dir = args.out
    os.makedirs(out_dir, exist_ok=True)
    fields = ["instance", "algorithm", "status", "required", "x", "time_sec", "group_ops", "memory_items", "params", "reason"]
    with open(os.path.join(out_dir, "results.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    with open(os.path.join(out_dir, "summary.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Algorithm"] + labels)
        w.writerows(mat)
    with open(os.path.join(out_dir, "summary.md"), "w", encoding="utf-8") as f:
        f.write("# Part 1 results\n\n| Instance | Algorithm | Status | x | Time (s) | Group ops | Memory | Parameters / reason |\n|---|---|---|---|---|---|---|---|\n")
        for r in t1:
            f.write("| " + " | ".join(str(c).replace("|", "/") for c in r) + " |\n")
        f.write("\n## Task 1.6 table\n\n| Algorithm | " + " | ".join(labels) + " |\n|" + "---|" * (len(labels) + 1) + "\n")
        for line in mat:
            f.write("| " + " | ".join(line) + " |\n")
        f.write("\n" + "\n".join(f"{i}. {n}" for i, n in enumerate(notes, 1)) + "\n")
    with open(os.path.join(out_dir, "details.json"), "w", encoding="utf-8") as f:
        json.dump([{k: v for k, v in r.items()} for r in rows], f, indent=1, default=str)

    passed = sum(r["status"] == "PASS" for r in rows)
    req_fail = [r for r in rows if r["required"] and r["status"] in ("FAIL", "TIMEOUT")]
    opt_fail = [r for r in rows if not r["required"] and r["status"] in ("FAIL",)]
    print(f"\nSummary: {passed} solved and verified, "
          f"{sum(r['status'] in ('INFEASIBLE', 'EXTRAPOLATED') for r in rows)} infeasible/extrapolated, "
          f"{sum(r['status'] == 'NOT RUN' for r in rows)} not run (budget), "
          f"{sum(r['status'] == 'N/A' for r in rows)} n/a, {len(req_fail)} required failures, "
          f"{len(opt_fail)} optional failures.")
    print("Saved: " + os.path.relpath(os.path.join(out_dir, "results.csv"), os.getcwd()) + ", summary.md, summary.csv, details.json")
    return 1 if req_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
